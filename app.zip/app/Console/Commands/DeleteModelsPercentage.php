<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;

class DeleteModelsPercentage extends Command
{
    protected $signature = 'models:delete-percentage {percentage=70}'; // Command name with default 70%
    protected $description = 'Delete a percentage of model files from the app/Models directory without confirmation';

    public function handle()
    {
        $modelsPath = app_path('Models'); // Path to "app/Models"

        if (!File::exists($modelsPath)) {
            $this->error('The app/Models directory does not exist.');
            return;
        }

        $files = File::files($modelsPath); // Get all model files

        if (empty($files)) {
            $this->error('No model files found in app/Models.');
            return;
        }

        // Get percentage to delete (default 70%)
        $percentage = (int) $this->argument('percentage');
        if ($percentage < 1 || $percentage > 100) {
            $this->error('Invalid percentage value. Enter a value between 1 and 100.');
            return;
        }

        // Calculate how many files to delete
        $numToDelete = (int) round(count($files) * ($percentage / 100));

        if ($numToDelete == 0) {
            $this->info('No files deleted, percentage is too low.');
            return;
        }

        // Randomly select files to delete
        shuffle($files);
        $filesToDelete = array_slice($files, 0, $numToDelete);

        // Perform deletion without confirmation
        foreach ($filesToDelete as $file) {
            File::delete($file);
            $this->info('Deleted: ' . $file->getFilename());
        }

        $this->info('Deleted ' . count($filesToDelete) . ' model files.');
    }
}
