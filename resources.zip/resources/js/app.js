require('./bootstrap');
require('./components/PointOfSale');
require('./components/PointOfSaleEdit');
require('./components/StartingCashInput');
