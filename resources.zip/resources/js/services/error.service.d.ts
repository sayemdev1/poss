declare class ErrorService {
    handle(error: any): void;
}
declare const _default: ErrorService;
export default _default;
