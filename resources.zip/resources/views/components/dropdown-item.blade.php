<li>
    <a {{ $attributes->merge(['class' => 'dropdown-item d-flex align-items-center small']) }}>
        {{ $slot }}
    </a>
</li>
