<ul {{ $attributes->merge(['class' => 'dropdown-menu shadow-sm rounded-3']) }}>
    {{ $slot }}
</ul>
