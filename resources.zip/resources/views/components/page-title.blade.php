<div class="text-black fw-bold text-start" style="font-size: 1.5rem;line-height: 2rem;">
    {{ $slot }}
</div>
