<td class="text-muted font-medium px-4 py-2 small text-start whitespace-nowrap align-middle">
    {{ $slot }}
</td>
