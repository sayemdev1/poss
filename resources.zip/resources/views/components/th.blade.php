<th class="text-muted font-medium px-4 py-3 text-uppercase small text-start whitespace-nowrap tracking-wider">
    {{ $slot }}
</th>
