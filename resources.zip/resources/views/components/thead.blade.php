<thead class="bg-gray-50">
    {{ $slot }}
</thead>
