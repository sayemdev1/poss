@extends('errors.master')

@section('content')
    Error 401
@endsection
