@extends('errors.master')

@section('content')
    Error 403
@endsection
