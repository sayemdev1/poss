@extends('errors.master')

@section('content')
    Error 404
@endsection
