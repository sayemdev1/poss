@extends('errors.master')

@section('content')
    Error 429
@endsection
