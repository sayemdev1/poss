@extends('errors.master')

@section('content')
    Error 500
@endsection
