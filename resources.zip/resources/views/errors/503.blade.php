@extends('errors.master')

@section('content')
    Error 503
@endsection
