<meta name="lang-value" content="{{ $settings->lang }}">
<meta name="dir-value" content="{{ $settings->dir }}">