<button class="btn btn-primary px-4" data-bs-toggle="modal" data-bs-target="#filterModal">
    <i class="bi bi-funnel align-middle"></i> @lang('Filter')
</button>
